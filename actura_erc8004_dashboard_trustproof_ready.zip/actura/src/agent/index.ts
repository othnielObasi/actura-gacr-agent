/**
 * ACTURA — Accountable Autonomous Trading Agent
 * Production-Grade Main Agent Loop
 *
 * "Not the smartest trader. The most accountable."
 *
 * Features:
 * - Structured logging with levels
 * - Config validation at startup
 * - Retry logic for external calls (IPFS, chain)
 * - Graceful shutdown (SIGINT/SIGTERM)
 * - State persistence (survives restarts)
 * - Position limit enforcement
 * - Scheduler with error recovery
 * - Health check endpoint
 */

import { config } from './config.js';
import { createLogger, getRecentLogs, getErrorLogs } from './logger.js';
import { validateConfig } from './validator.js';
import { Scheduler } from './scheduler.js';
import { retry } from './retry.js';
import { saveState, loadState, type PersistedState } from './state.js';
import { runStrategy, resetStrategy, type MarketData } from '../strategy/momentum.js';
import { RiskEngine } from '../risk/engine.js';
import { buildTradeArtifact, enrichArtifact, attachGovernanceEvidence } from '../trust/artifact-emitter.js';
import { getLastTrustScore } from '../trust/trust-policy-scorecard.js';
import { evaluateSupervisoryDecision, applySupervisorySizing, summarizeSupervisoryDecision } from './supervisory-meta-agent.js';
import { generateReasoning } from '../strategy/ai-reasoning.js';
import { applySymbolicReasoning, recordOutcome } from '../strategy/neuro-symbolic.js';
import { runAdaptation, recordTradeOutcome, getAdaptiveParams, getAdaptationSummary, type AdaptationArtifact } from '../strategy/adaptive-learning.js';
import { uploadArtifact } from '../trust/ipfs.js';
import { saveCheckpoint, getCheckpoints, getTradeCheckpoints } from '../trust/checkpoint.js';
import { computeMarketState } from '../data/market-state.js';
import { evaluateOracleIntegrity } from '../security/oracle-integrity.js';
import { evaluateMandate, getDefaultMandate, buildMandateRiskChecks } from '../chain/agent-mandate.js';
import { simulateExecution } from '../chain/execution-simulator.js';
import { generateSimulatedData, appendCandle } from '../data/price-feed.js';
import { getOperatorControlState, getLatestOperatorAction } from './operator-control.js';

const log = createLogger('AGENT');

const MODE = process.env.MODE || 'simulation';

// ──── Agent State ────
const INITIAL_CAPITAL = 10000;
const MAX_OPEN_POSITIONS = 5;

let marketData: MarketData;
let riskEngine: RiskEngine;
let scheduler: Scheduler;
let agentId: number | null = null;
let cycleCount = 0;

// ──── Initialization ────

function initAgent(): void {
  console.log('');
  console.log('═══════════════════════════════════════════');
  console.log('  ACTURA — Accountable Autonomous Trading Agent');
  console.log('  Sovereign AI Lab × ERC-8004');
  console.log('═══════════════════════════════════════════');
  console.log('');

  // Validate config
  const validation = validateConfig();
  if (!validation.valid) {
    log.fatal('Configuration invalid — cannot start');
    process.exit(1);
  }

  // Try to restore state
  const savedState = loadState();

  if (savedState && savedState.capital > 0) {
    log.info('Restoring from saved state', {
      capital: savedState.capital,
      positions: savedState.openPositions.length,
      lastCycle: savedState.lastCycle,
    });
    riskEngine = new RiskEngine(savedState.capital);
    cycleCount = savedState.lastCycle;

    // Restore positions
    for (const pos of savedState.openPositions) {
      riskEngine.openPosition(pos);
    }
  } else {
    riskEngine = new RiskEngine(INITIAL_CAPITAL);
    cycleCount = 0;
  }

  // Generate initial market data
  marketData = generateSimulatedData(60, 3000, 0.02, 0.0003);
  resetStrategy();

  log.info('Agent initialized', {
    capital: riskEngine.getCapital(),
    pair: config.tradingPair,
    strategy: `SMA${config.strategy.smaFast}/${config.strategy.smaSlow}`,
    maxDailyLoss: `${config.maxDailyLossPct * 100}%`,
    maxDrawdown: `${config.maxDrawdownPct * 100}%`,
    maxPositions: MAX_OPEN_POSITIONS,
  });
}

// ──── Trading Cycle ────

async function runCycle(): Promise<void> {
  cycleCount++;
  const cycleStart = Date.now();
  const operatorControl = getOperatorControlState();

  // Step 1: Update market data
  const lastPrice = marketData.prices[marketData.prices.length - 1];
  const vol = 0.02;
  const shock = vol * (Math.random() * 2 - 1);
  const newPrice = lastPrice * (1 + 0.0002 + shock);
  const range = newPrice * vol * 0.3;

  marketData = appendCandle(marketData, {
    timestamp: new Date().toISOString(),
    open: lastPrice,
    high: newPrice + Math.abs(Math.random() * range),
    low: newPrice - Math.abs(Math.random() * range),
    close: Math.round(newPrice * 100) / 100,
    volume: Math.round(Math.random() * 1000),
  });

  // Trim data window
  if (marketData.prices.length > 200) {
    marketData.prices = marketData.prices.slice(-200);
    marketData.highs = marketData.highs.slice(-200);
    marketData.lows = marketData.lows.slice(-200);
    marketData.timestamps = marketData.timestamps.slice(-200);
  }

  // Step 2: Run strategy
  const capital = riskEngine.getCapital();
  const strategyOutput = runStrategy(marketData, capital);

  // Step 2a: Oracle integrity guard — block suspicious or stale market states
  const oracleIntegrity = evaluateOracleIntegrity({
    prices: marketData.prices,
    highs: marketData.highs,
    lows: marketData.lows,
    timestamps: marketData.timestamps,
  });

  if (!oracleIntegrity.passed) {
    strategyOutput.signal.direction = 'NEUTRAL';
    strategyOutput.signal.confidence = 0;
    strategyOutput.signal.reason = `[ORACLE BLOCK] ${oracleIntegrity.blockers.join('; ')} | ${strategyOutput.signal.reason}`;
    strategyOutput.positionSizeRaw = 0;
    strategyOutput.positionSize = 0;
    strategyOutput.stopLossPrice = null;
    (strategyOutput.signal as any).oracleIntegrityStatus = 'blocked';
  } else {
    (strategyOutput.signal as any).oracleIntegrityStatus = oracleIntegrity.status;
  }

  // Step 2b: Neuro-symbolic reasoning — apply symbolic rules to the raw signal
  const positions = riskEngine.getOpenPositions();
  const cbState = riskEngine.getStatus().circuitBreaker;
  const cognitive = applySymbolicReasoning(
    strategyOutput,
    positions.map(p => ({ side: p.side, entryPrice: p.entryPrice })),
    capital,
    cbState.drawdownPct,
    cbState.dailyPnlPct,
  );

  // Apply symbolic adjustments to strategy output
  if (cognitive.override || cognitive.rulesFired > 0) {
    strategyOutput.signal.direction = cognitive.adjustedSignal as 'LONG' | 'SHORT' | 'NEUTRAL';
    strategyOutput.signal.confidence = cognitive.adjustedConfidence;
    if (cognitive.override) {
      strategyOutput.signal.reason = `[SYMBOLIC OVERRIDE] ${cognitive.overrideReason}`;
    }
  }

  // Step 2c: Supervisory meta-agent — trust-aware capital steward
  const lastTrustScore = getLastTrustScore(agentId);
  const structureRegime = (strategyOutput.signal.structureRegime ?? 'UNKNOWN') as 'TRENDING' | 'RANGING' | 'STRESSED' | 'UNCERTAIN' | 'UNKNOWN';
  const edgeAllowed = strategyOutput.signal.edge?.allowed ?? true;
  const supervisory = evaluateSupervisoryDecision({
    trustScore: lastTrustScore,
    drawdownPct: cbState.drawdownPct,
    structureRegime,
    edgeAllowed,
    volatilityRegime: strategyOutput.indicators.volatility
      ? (strategyOutput.indicators.volatility > 0.04 ? 'extreme'
        : strategyOutput.indicators.volatility > 0.03 ? 'high'
        : strategyOutput.indicators.volatility < 0.01 ? 'low'
        : 'normal')
      : 'normal',
    currentOpenPositions: positions.length,
    maxOpenPositions: MAX_OPEN_POSITIONS,
  });

  if (!supervisory.canTrade) {
    strategyOutput.signal.direction = 'NEUTRAL';
    strategyOutput.signal.confidence = 0;
    strategyOutput.signal.reason = `[SUPERVISORY BLOCK] ${summarizeSupervisoryDecision(supervisory)} | ${strategyOutput.signal.reason}`;
    strategyOutput.positionSizeRaw = 0;
    strategyOutput.positionSize = 0;
    strategyOutput.stopLossPrice = null;
  } else {
    const preSupervisorySize = strategyOutput.positionSizeRaw;
    const resizedRaw = applySupervisorySizing(
      preSupervisorySize,
      capital,
      strategyOutput.currentPrice,
      supervisory,
    );
    strategyOutput.positionSizeRaw = resizedRaw;
    strategyOutput.positionSize = resizedRaw;
    if (resizedRaw === 0) {
      strategyOutput.signal.direction = 'NEUTRAL';
      strategyOutput.signal.confidence = 0;
      strategyOutput.signal.reason = `[SUPERVISORY THROTTLE->ZERO] ${summarizeSupervisoryDecision(supervisory)} | ${strategyOutput.signal.reason}`;
      strategyOutput.stopLossPrice = null;
    } else if (resizedRaw < preSupervisorySize) {
      strategyOutput.signal.reason = `[SUPERVISORY THROTTLE] ${summarizeSupervisoryDecision(supervisory)} | ${strategyOutput.signal.reason}`;
    }
  }

  // Step 2d: Agent mandate enforcement — asset/protocol/capital permissions
  const mandate = getDefaultMandate(Math.max(capital, 10000));
  const mandateDecision = evaluateMandate({
    mandate,
    strategyOutput,
    capitalUsd: capital,
    protocol: config.allowedProtocols[0] ?? 'uniswap',
    asset: config.tradingPair,
    dailyPnlPct: cbState.dailyPnlPct,
  });
  (strategyOutput.signal as any).mandateApproved = mandateDecision.approved && !mandateDecision.requiresHumanApproval;

  if (!mandateDecision.approved || mandateDecision.requiresHumanApproval) {
    strategyOutput.signal.direction = 'NEUTRAL';
    strategyOutput.signal.confidence = 0;
    const prefix = mandateDecision.requiresHumanApproval ? '[MANDATE HUMAN APPROVAL]' : '[MANDATE BLOCK]';
    strategyOutput.signal.reason = `${prefix} ${mandateDecision.reasons.join('; ') || 'mandate restriction'} | ${strategyOutput.signal.reason}`;
    strategyOutput.positionSizeRaw = 0;
    strategyOutput.positionSize = 0;
    strategyOutput.stopLossPrice = null;
  }

  // Step 3: Risk engine evaluation
  const riskDecision = riskEngine.evaluate(strategyOutput);
  riskDecision.checks.push(...buildMandateRiskChecks(mandateDecision));

  // Step 4: Position limit check (additional production guard)
  const openCount = riskEngine.getOpenPositions().length;
  const positionLimitHit = openCount >= MAX_OPEN_POSITIONS;

  if (riskDecision.approved && positionLimitHit) {
    log.warn(`Position limit reached (${openCount}/${MAX_OPEN_POSITIONS}) — trade skipped`);
  }

  let shouldExecute = riskDecision.approved && !positionLimitHit;

  // Step 4b: Execution simulation — required pre-trade safety stage
  const executionSimulation = simulateExecution({ strategyOutput, riskDecision });
  if (shouldExecute && !executionSimulation.allowed) {
    shouldExecute = false;
    strategyOutput.signal.reason = `[SIMULATION BLOCK] ${executionSimulation.reason} | ${strategyOutput.signal.reason}`;
    log.warn('Execution simulation blocked trade', executionSimulation);
  }

  // Step 5: Build validation artifact (ALWAYS — even for rejected trades)
  let artifact = buildTradeArtifact(strategyOutput, riskDecision, agentId);
  artifact = attachGovernanceEvidence(artifact, {
    mandateDecision,
    oracleIntegrity,
    executionSimulation,
    operatorControl: {
      ...operatorControl,
      latestAction: getLatestOperatorAction(),
    },
  });

  // Add cognitive + supervisory layer data to artifact
  (artifact as any).supervisory = supervisory;

  if (cognitive.rulesFired > 0) {
    (artifact as any).cognitive = {
      rulesEvaluated: cognitive.rulesEvaluated,
      rulesFired: cognitive.rulesFired,
      override: cognitive.override,
      overrideReason: cognitive.overrideReason,
      adjustments: cognitive.ruleResults.filter(r => r.fired).map(r => ({
        rule: r.ruleName,
        action: r.action,
        reason: r.reason,
        confidenceAdjust: r.confidenceAdjustment,
      })),
      originalSignal: cognitive.originalSignal,
      originalConfidence: cognitive.originalConfidence,
    };
  }

  // Step 5b: Enrich with AI reasoning + market snapshot + confidence intervals
  const aiReasoning = await generateReasoning(
    strategyOutput, riskDecision, marketData.prices, capital, openCount
  );
  artifact = enrichArtifact(artifact, aiReasoning, marketData.prices);

  // Step 6: Upload to IPFS with retry
  let ipfsResult = null;
  if (shouldExecute) {
    try {
      ipfsResult = await retry(
        () => uploadArtifact(artifact),
        { maxRetries: 2, baseDelayMs: 500, label: 'IPFS upload' }
      );
    } catch (e) {
      log.error('IPFS upload failed after retries — proceeding without artifact link');
    }
  }

  // Step 7: Record checkpoint
  const checkpoint = saveCheckpoint(strategyOutput, riskDecision, artifact, ipfsResult);

  // Step 8: Execute trade
  if (shouldExecute) {
    if (MODE === 'live' && agentId) {
      // REAL EXECUTION: Sign intent → Risk Router → Validation → Reputation
      const execResult = await executeTrade(strategyOutput, riskDecision, artifact, agentId);
      if (execResult.success) {
        checkpoint.onChainTxHash = execResult.intentTxHash;
        ipfsResult = ipfsResult || { cid: execResult.artifactIpfsCid!, uri: execResult.artifactIpfsUri!, gatewayUrl: '' };
      } else {
        log.warn('On-chain execution failed — recording locally only', { error: execResult.error });
      }
    }

    // Always record position locally (for our risk engine tracking)
    riskEngine.openPosition({
      asset: config.tradingPair,
      side: strategyOutput.signal.direction as 'LONG' | 'SHORT',
      size: riskDecision.finalPositionSize,
      entryPrice: strategyOutput.currentPrice,
      stopLoss: riskDecision.stopLossPrice,
      openedAt: new Date().toISOString(),
    });
  }

  // Step 9: Update trailing stops and check stop-losses
  const currentPrice = strategyOutput.currentPrice;
  const closedPositions = riskEngine.updateStops(currentPrice);

  // Step 9b: Record outcomes for neuro-symbolic + adaptive learning
  for (const closed of closedPositions) {
    const pos = positions.find(p => p.id === closed.id);
    if (pos) {
      const pnlPct = pos.entryPrice > 0 ? closed.pnl / (pos.entryPrice * pos.size) * 100 : 0;
      recordOutcome({
        direction: pos.side,
        confidence: strategyOutput.signal.confidence,
        price: currentPrice,
        result: closed.pnl >= 0 ? 'win' : 'loss',
        timestamp: new Date().toISOString(),
      });
      recordTradeOutcome({
        direction: pos.side as 'LONG' | 'SHORT',
        entryPrice: pos.entryPrice,
        exitPrice: currentPrice,
        pnlPct,
        stopHit: true,
        regime: riskDecision.volatility.regime as any,
        confidence: strategyOutput.signal.confidence,
        timestamp: new Date().toISOString(),
      });
    }
  }

  // Step 10: Adaptive learning (every 10 cycles)
  if (cycleCount % 10 === 0) {
    const adaptations = runAdaptation(cycleCount);
    for (const adapt of adaptations) {
      log.info(`Adaptation: ${adapt.parameter} ${adapt.previousValue} → ${adapt.newValue} (${adapt.trigger})`);
    }
    persistState();
  }

  const currentPositions = riskEngine.getOpenPositions();

  // Log cycle
  const elapsed = Date.now() - cycleStart;
  const marker = shouldExecute ? '✅' : (riskDecision.circuitBreaker.active ? '🛑' : '⏸️');

  log.info(
    `${marker} Cycle ${cycleCount} | ` +
    `$${strategyOutput.currentPrice.toFixed(2)} | ` +
    `${strategyOutput.signal.direction} (${strategyOutput.signal.confidence.toFixed(2)}) | ` +
    `Cap: $${capital.toFixed(0)} | ` +
    `Pos: ${currentPositions.length}/${MAX_OPEN_POSITIONS} | ` +
    `${cognitive.rulesFired > 0 ? `Rules: ${cognitive.rulesFired} | ` : ''}` +
    `Oracle: ${oracleIntegrity.status} | Sim: ${executionSimulation.reason} | ` +
    `${elapsed}ms`
  );

  if (shouldExecute) {
    log.info(
      `  → ${strategyOutput.signal.direction} ${riskDecision.finalPositionSize.toFixed(4)} @ $${strategyOutput.currentPrice.toFixed(2)} | ` +
      `Stop: $${riskDecision.stopLossPrice?.toFixed(2) ?? 'N/A'} | ` +
      `IPFS: ${ipfsResult?.cid?.slice(0, 16) ?? 'none'}`
    );
  }
}

// ──── State Persistence ────

function persistState(): void {
  const status = riskEngine.getStatus();
  const state: PersistedState = {
    capital: status.capital,
    openPositions: status.openPositions,
    peakCapital: status.circuitBreaker.peakCapital,
    totalTrades: status.totalTrades,
    totalPnl: status.capital - INITIAL_CAPITAL,
    agentId,
    lastCycle: cycleCount,
    lastSavedAt: new Date().toISOString(),
  };
  saveState(state);
}

// ──── Public Accessors (for Dashboard/MCP) ────

export function getAgentState() {
  return {
    cycleCount,
    running: scheduler?.isRunning() ?? false,
    agentId,
    risk: riskEngine?.getStatus() ?? null,
    market: marketData ? computeMarketState(marketData) : null,
    recentCheckpoints: getCheckpoints(10),
    scheduler: scheduler?.getState() ?? null,
    maxPositions: MAX_OPEN_POSITIONS,
    operatorControl: getOperatorControlState(),
  };
}

export function getHealthCheck() {
  const state = scheduler?.getState();
  return {
    status: state?.running ? 'healthy' : 'stopped',
    uptime: state?.uptime ?? 0,
    cycles: state?.cycleCount ?? 0,
    errors: state?.errorCount ?? 0,
    consecutiveErrors: state?.consecutiveErrors ?? 0,
    lastCycle: state?.lastCycleAt,
    lastError: state?.lastError,
    capital: riskEngine?.getCapital() ?? 0,
    positions: riskEngine?.getOpenPositions().length ?? 0,
  };
}

export function getLogs(limit?: number) {
  return getRecentLogs(limit);
}

export function getErrors(limit?: number) {
  return getErrorLogs(limit);
}

export { getCheckpoints, getTradeCheckpoints };

export function initAgent_export(): void { initAgent(); }
export function stopAgent(): void { scheduler?.shutdown('manual'); }

// ──── Simulation Mode (for testing) ────

export async function runSimulation(cycles: number = 50): Promise<void> {
  initAgent();

  log.info(`Running ${cycles} trading cycles (simulation mode)`);

  for (let i = 0; i < cycles; i++) {
    await runCycle();
  }

  // Print summary
  const status = riskEngine.getStatus();
  const allCheckpoints = getCheckpoints(1000);
  const trades = allCheckpoints.filter(c => c.riskDecision.approved);
  const marketState = computeMarketState(marketData);

  console.log('\n═══════════════════════════════════════════');
  console.log('  SIMULATION COMPLETE');
  console.log('═══════════════════════════════════════════');
  console.log(`  Cycles:         ${cycleCount}`);
  console.log(`  Trades:         ${trades.length}`);
  console.log(`  Final Capital:  $${status.capital.toFixed(2)}`);
  console.log(`  PnL:            $${(status.capital - INITIAL_CAPITAL).toFixed(2)} (${(((status.capital - INITIAL_CAPITAL) / INITIAL_CAPITAL) * 100).toFixed(2)}%)`);
  console.log(`  Open Positions: ${status.openPositions.length}`);
  console.log(`  Circuit Breaks: ${status.circuitBreaker.tripsToday}`);
  console.log(`  Artifacts:      ${allCheckpoints.length} generated`);
  console.log(`  Current Price:  $${marketState.currentPrice.toFixed(2)}`);
  console.log(`  Volatility:     ${marketState.volatility?.toFixed(4) ?? 'N/A'}`);
  console.log('═══════════════════════════════════════════\n');

  persistState();
}

// ──── Entry Point ────
import { executeTrade, preflight, claimSandboxCapital } from '../chain/executor.js';
import { startDashboard } from '../dashboard/server.js';
import { startMcpServer } from '../mcp/server.js';

// Start servers
startDashboard(3000);
startMcpServer(3001);

// Run in simulation mode (swap for scheduler in production)
// Run in selected mode
if (MODE === 'live') {
  // Production: preflight → claim sandbox → scheduler
  initAgent();

  (async () => {
    // Preflight checks
    const flight = await preflight();
    if (!flight.ready) {
      log.warn('Preflight issues found — some features may not work');
    }

    // Claim sandbox capital (idempotent — safe to call multiple times)
    if (config.capitalVaultAddress) {
      try {
        await claimSandboxCapital();
      } catch (e) {
        log.warn('Sandbox claim failed — may already be claimed', { error: String(e) });
      }
    }

    // Start scheduled trading
    scheduler = new Scheduler(config.tradingIntervalMs);
    scheduler.onShutdown(() => {
      log.info('Persisting state on shutdown...');
      persistState();
    });
    scheduler.start(runCycle, () => {
      log.info('Daily circuit breaker reset');
      riskEngine.resetDaily();
    });
  })().catch(err => {
    log.fatal('Live mode startup failed', { error: String(err) });
    process.exit(1);
  });
} else {
  // Simulation: run N cycles fast
  runSimulation(50).catch(err => {
    log.fatal('Simulation failed', { error: String(err) });
    process.exit(1);
  });
}
